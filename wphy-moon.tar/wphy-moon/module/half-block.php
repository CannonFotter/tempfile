<div class="col-sm-6 half-block">
  <div class="title">
    <h3><?php echo $data['title']; ?></h3>
  </div>
  <div class="content">
    <p>
    <?php echo $data['content']; ?>
    </p>
  </div>
  <a href="<?php echo $data['link']; ?>" class="readmore" target="_blank">查看详情</a>
</div>