<div class="text-block">
  <div class="title"><?php echo $data['title']; ?></div>
  <div class="content"><?php echo $data['content']; ?></div>
</div>