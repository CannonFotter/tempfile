<div class=" option-block  " style="background-color:rgba(<?php echo $data['color']; ?>,0.9);">
  <a href="<?php echo $data['url']; ?>" target="_blank">
    <span class="icon"><?php echo $data['icon']; ?></span>
    <div class="title"><?php echo $data['title']; ?></div>
  </a>
</div>