<?php 
if (get_option('show_team')=='checked') {
?>

<?php 
}
?>