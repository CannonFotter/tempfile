<div class="image-post">
  <div class="image"><img src="<?php echo $data['image']; ?>" alt="<?php echo $data['link']; ?>"></div>
  <div class="info">
    <div class="title"><a target="_blank" href="<?php echo $data['link']; ?>"><?php echo $data['title']; ?></a></div>
    <div class="content"><?php echo $data['content']; ?></div>
    <div class="date"><a target="_blank" href="<?php echo $data['link']; ?>">查看详情</a></div>
  </div>  
</div>