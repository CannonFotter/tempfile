<div class="image-block-slide">
  <a href="<?php echo $data['link']; ?>">
    <img src="<?php echo $data['image']; ?>" alt="<?php echo $data['title']; ?>" class="animated">
    <div class="info">
      <div class="title animated">
        <?php echo $data['title']; ?>
      </div>
      <div class="content animated">
        <?php echo $data['excerpt']; ?>
      </div>
    </div>      
  </a>
</div>