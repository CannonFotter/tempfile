jQuery(document).ready(function($){ 

});